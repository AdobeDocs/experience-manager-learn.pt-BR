package com.aemformscs.documentservices;

public class ExecuteAssemblerService {

	public static void main(String[] args) {
		String AEM_FORMS_CS = "YOUR_SERVER_NAME";
		String assemblePDFURL = AEM_FORMS_CS+"/adobe/forms/assembler/ddx/invoke";
		String convertToPDFAURL = AEM_FORMS_CS+"/adobe/forms/assembler/pdfa/convert";
		String validatePDFAURL = AEM_FORMS_CS+"/adobe/forms/assembler/pdfa/validate";
		new AssemblePDFFiles().assemblePDF(assemblePDFURL);
		//new PDFAUtilities().validatePDFA(validatePDFAURL);
		//new PDFAUtilities().toPDFA(convertToPDFAURL);
		

	}

}
