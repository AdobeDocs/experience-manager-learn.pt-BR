/**
* StoreFilesWithData
* @return {OPTIONS} drop down options 
 */
function StoreFilesWithData()
{
    guideBridge.getFormDataObject({
    success: function(resultObj) {

        console.log("Got data");
        afFormData = resultObj.data;
        var htmlFormData = afFormData.toHTMLFormData();
        var formData = new FormData();
        formData.append("dataXml", afFormData.options.data);
        //formData.append("attachments",afFormData.options.attachments[0].options.data);

// Display the key/value pairs
        for (var pair of htmlFormData.entries()) {
            debugger;
            console.log(pair[0] + ', ' + pair[1]);
            if (pair[0] == "fileAttachments") {
                console.log("got attachments with name " + pair[1].name);
                formData.append(pair[1].name, pair[1]);
            }


        }

        var settings = {
            "contentType": false,
            "mimeType": "multipart/form-data",

            "processData": false,
            "url": "/bin/save2",
            "method": "POST",
            data: formData,
        }
        $.ajax(settings).done(function(response) {
            console.log("got response");
            debugger;



        })


        debugger;

    },

});
}
