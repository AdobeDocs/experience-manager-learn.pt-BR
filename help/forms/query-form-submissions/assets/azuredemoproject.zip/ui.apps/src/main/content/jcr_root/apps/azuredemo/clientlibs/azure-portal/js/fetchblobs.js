$(document).ready(function() {

     $(".fetchresults").click(function()
     {
        var formPath = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].formName[0]");
        console.log(formPath.value);
        var searchField = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].fieldName[0]");
        console.log(searchField.value);
        var searchValue = guideBridge.resolveNode("guide[0].guide1[0].guideRootPanel[0].fieldChoice[0]");
        console.log(searchValue.value)
        console.log("searchCriteria="+searchField.value+"="+"'"+searchValue.value+"'");
        var searchCriteria = "searchCriteria="+searchField.value+"="+"'"+searchValue.value+"'";
        var geturl = '/content/azuredemo/api/getBlobsByIndexTags/jcr:content.json?formPath='+formPath.value+"&"+searchCriteria;
        console.log(geturl);


       $.ajax({

             url: geturl,
             type : 'GET',
             dataType : 'json',
             success : function(response) {
                 //console.log("Got results"+response.blobs[0].blobID);
                 var tableHeadingRow = document.createElement('tr');
                 var blob = response.blobs[0];

                 const keys = Object.keys(blob);
                 console.log("The element name is "+blob[keys[0]]);
                 console.log("Element name ", keys);
                 var tableHeadings = [];
                for(const key in keys)
                    {
                        console.log("The table heading is "+keys[key]);
                        tableHeadings.push(keys[key]);
                        const th = document.createElement('th');
                        th.textContent = keys[key];
                        tableHeadingRow.appendChild(th);
                    }
                    const view = document.createElement('th');
                    view.textContent = "View Form";
                    tableHeadingRow.appendChild(view);

                $("#searchresults").append(tableHeadingRow);



                for(i=0;i<response.blobs.length;i++)
                        {
                            var blobObject = response.blobs[i];
                            const keys = Object.keys(blobObject);
                            var formName = blobObject["formName"];
                            console.log("The element name is "+blob[keys[0]]);
                            var row = "<tr>"
                            console.log("Element name ", keys);
                             for(j=0;j<tableHeadings.length;j++)
                                            {
                                                 console.log("The heading value is  is "+tableHeadings[j]);
                                                 row = row+"<td>"+blobObject[tableHeadings[j]]+"</td>";
                                            }

                                console.log(row+"<td>View Form</td></tr>");
                            $("#searchresults").append(row+"<td><a href=http://localhost:4502/content/dam/formsanddocuments/azureportal/"+formName+"/jcr:content?wcmmode=disabled&guid="+blobObject["blobID"]+">View Form</a></td></tr>");



                            }




             }
         });
     });


});