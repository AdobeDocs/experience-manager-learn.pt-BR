@Version("1.0")
package com.azuredemo.core.SaveAndFetchFromAzure;
import org.osgi.annotation.versioning.Version;