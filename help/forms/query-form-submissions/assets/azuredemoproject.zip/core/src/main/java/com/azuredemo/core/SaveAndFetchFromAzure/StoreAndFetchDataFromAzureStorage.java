package com.azuredemo.core.SaveAndFetchFromAzure;
import javax.jcr.Session;
import java.io.InputStream;

public interface StoreAndFetchDataFromAzureStorage {
    public String saveFormDatainAzure(String formData,String contentType,String metaDataTags);
    public String saveFormDatainAzure(String formData,String contentType);

    public String saveFormAttachmentinAzure(InputStream attachmentStream, String fileName,String contentType);
    public String getBlobData(String blobID);
    public String getMetaDataTags(String submittedFormName,String formPath, Session session,String formData);
    public String getSearchableFields(String formPath, Session session);
    public String getFormsList(String folderPath,Session session);
    public String getOptions(String formPath,String fieldName, Session session);

    public String getBlobs(String metaDataQuery);


}
