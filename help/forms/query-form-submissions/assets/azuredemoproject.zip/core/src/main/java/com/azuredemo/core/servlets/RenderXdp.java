package com.azuredemo.core.servlets;

import com.adobe.aemfd.docmanager.Document;
import com.adobe.fd.forms.api.*;
import com.azuredemo.core.SaveAndFetchFromAzure.StoreAndFetchDataFromAzureStorage;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletResourceTypes;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;
import javax.servlet.Servlet;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

@Component(
        service={Servlet.class }
)

@SlingServletResourceTypes(
        resourceTypes="azure/renderxdp",
        methods= "GET",
        extensions="json"
)
public class RenderXdp extends SlingAllMethodsServlet implements Serializable {
    private static final long serialVersionUID = 1L;
    private final transient Logger log = LoggerFactory.getLogger(this.getClass());
    @Reference
    FormsService formsService;


    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {
        String uri = "crx:///content/dam/formsanddocuments";
        PDFFormRenderOptions renderOptions = new PDFFormRenderOptions();
        renderOptions.setAcrobatVersion(AcrobatVersion.Acrobat_11);
        renderOptions.setRenderAtClient(RenderAtClient.NO);
        renderOptions.setContentRoot(uri);
        Document interactivePDF = null;
        try {
            interactivePDF = formsService.renderPDFForm("testsubmision.xdp", null, renderOptions);
            interactivePDF.copyToFile(new File("rendered.pdf"));
        } catch (FormsServiceException e) {
            System.out.println("Error is "+e.getMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
}
